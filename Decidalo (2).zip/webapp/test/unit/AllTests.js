sap.ui.define([
	"Project/Decidalo/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
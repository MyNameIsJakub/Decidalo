sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment"
], function (Controller, JSONModel, MessageToast, Fragment) {
	"use strict";
	return Controller.extend("Project.Decidalo.controller.loggedIn", {
		onInit: function () {
			var oData = {
				loginData: {
					eMail: ""
				}
			};
			var oModel = new JSONModel(oData);
			this.getView().setModel(oModel);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("loggedIn").attachPatternMatched(this._onObejctMatched, this);
		},
		
		_onObejctMatched: function (oEvent) {
			var text = oEvent.getParameter("arguments").text;
			this.getView().getModel().setProperty("/loginData/eMail", text);
		},
		
		onTool1Press: function () {
			var eMail = this.getView().getModel().getProperty("/loginData/eMail");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CreateUser", {
				text: eMail
			});
		},
		
		handleOpen: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment("Project.Decidalo.view.userButton", this);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.openBy(oButton);
		},
		
		onLogoutButtonPress: function () {
			MessageToast.show("Sie wurden erfolgreich ausgeloggt");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Home");
		}
	});
});